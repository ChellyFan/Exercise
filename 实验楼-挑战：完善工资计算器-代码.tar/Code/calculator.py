#!/usr/bin/env python3
import sys


def calculate(str):
    try:
        input_ = str.split(':')
        id_ = input_[0]
        wage_ = int(input_[1])
    except:
        print("Parameter Error")
    tax = 0
    tax_in = wage_ * 0.835 - 5000
    if tax_in <= 0:
        tax = 0
    elif tax_in > 0 and tax_in <= 3000:
        tax = tax_in * 0.03
    elif tax_in > 3000 and tax_in <= 12000:
        tax = tax_in * 0.10 - 210
    elif tax_in > 12000 and tax_in <= 25000:
        tax = tax_in * 0.20 - 1410
    elif tax_in > 25000 and tax_in <= 35000:
        tax = tax_in * 0.25 - 2660
    elif tax_in > 35000 and tax_in <= 55000:
        tax = tax_in * 0.30 - 4410
    elif tax_in > 55000 and tax_in <= 80000:
        tax = tax_in * 0.35 - 7160
    elif tax_in > 80000:
        tax = tax_in * 0.45 - 15160
    wage_aftax = wage_ * 0.835 - tax
    print(id_ + ':{:.2f}'.format(wage_aftax))

if __name__ == '__main__':
    for x in sys.argv[1:]:
        calculate(x)
